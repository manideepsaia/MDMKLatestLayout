export class Practice {
    id: number;
    practiceName: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    // location:string;
    zipcode: number;
    practiceheader: string;
    tinnum: number;
}
