export class mapDosToAttorney {
    id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    practice: string;
    role: string;

}