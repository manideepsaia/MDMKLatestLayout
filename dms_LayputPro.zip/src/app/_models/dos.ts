export class dos{

     dosstring:string='';
  //  dosFrom:Array<Date>=[]
   // dosTo:Array<Date>=[];
   index:number=null;
    
  }
  
  
  
  
  